<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Contact Us</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #000000;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}



body {font-family: Calibri, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  align: center;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=send] {
  background-color: #04AA6D;
  color: white;
  padding: 8px 10px;
  border: none;
  border-radius: 2px;
  cursor: pointer;
}

input[type=send]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 10px;
  background-color: #f2f2f2;
  padding: 20px;
}

* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 50%;
  padding: 2px;
  height: 620px; 
}

.row:after {
  content: "";
  display: table;
  clear: both;
  
}


.fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

</style>
</head>
</head>
<body>
	<div class="wrapper">
			<nav class="navbar">
				<img class="logo"src="img/car_icon.png" href="#">
				<ul>
					<li><a href="home.php">Home</a></li>
					<li>
						<div class="dropdown">
							<a href="model.html"<span>Model</span></a>
								<div class="dropdown-content">
									<a href="ativa_detail.html">Ativa detail</a>
									<a href="myvi_detail.html">Myvi detail</a>

								</div>
						
						</div>
					</li>
					<li><a href="promotion.html">Promotion</a></li>
					<li><a href="testimonial.php">Testimonial</a></li>
					<li><a class="active">Contact Us</a></li>
				</ul>
			</nav>
			
	</div>
<body>
<div class="row">
  <br><br><br><br><br><br><div class="column" style="background-color:#fff;">

  <br><iframe src="https://maps.google.com/maps?q=jalan%20anggerik%20alor%20setar&t=&z=13&ie=UTF8&iwloc=&output=embed" 
  width="650" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
  </div>
  <div class="column" style="background-color:#fff;">
    <center><h2><b>CONTACT US</b></h2>
	<p><i> Have something to say? Let us know</p></center>
    <div class="container">
    <input type="text" id="name" name="name" placeholder="Name">
    <input type="text" id="email" name="email" placeholder="Email Address">
	<textarea id="text" name="message" placeholder="Message" style="height:150px"></textarea>

    <center><input type="send" value="SEND"></center>
	
 </div>
  </div></br></br></br></br></br></br>
  
 <br><h2>Address</h2>
 <p>Lot 11 Jalan Anggerik, Alor Setar, Kedah darul Aman, Malaysia</p><//br>
 <br><h2>We are open</h2>
 <p>10am-6pm</p></br>
 <br><h2>Phone</h2>
 <p>044646440</p></br>
 <br><h2>Email</h2>
 <p>peroduacarstore@gmail.com.my</p></br>
 
 
 <body>

<br><center><h2>Follow us on</h2></br>


<a href="https://www.facebook.com/Perodua/" class="fa fa-facebook"></a>
<a href="https://www.instagram.com/perodua/" class="fa fa-instagram"></a>
<a href="https://www.youtube.com/c/Perodua" class="fa fa-youtube"></a></center>
</body>
</div>
</body>
</head>
</html>