<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Perodua Car Store</title>
	<link rel="stylesheet" href="css/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	
<style>
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #000000;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.mySlides {display:none}
.w3-left, .w3-right, .w3-badge {cursor:pointer}
.w3-badge {height:13px;width:13px;padding:0}


* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  font-size: 17px;
}

.container {
  position: relative;
  max-width: 800px;
  margin: 0 auto;
}

.container img {vertical-align: middle;}

.container .content {
  position: absolute;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
}

.fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}
</style>
</head>
<body>
	<div class="wrapper">
			<nav class="navbar">
				<img class="logo"src="img/car_icon.png" href="#">
				<ul>
					<li><a class="active"href="">Home</a></li>
					<li>
						<div class="dropdown">
							<a href="model.html"<span>Model</span></a>
								<div class="dropdown-content">
									<a href="ativa_detail.html">Ativa detail</a>
									<a href="myvi_detail.html">Myvi detail</a>

								</div>
						
						</div>
					</li>
					<li><a href="promotion.html">Promotion</a></li>
					<li><a href="testimonial.php">Testimonial</a></li>
					<li><a href="contactus.php">Contact Us</a></li>
				</ul>
			</nav>
			
	</div>
	
	<br><br><br><div class="w3-container"></div></br></br></br>

<br><br><br><br><center><div class="w3-content w3-display-container" style="max-width:800px">
  <img class="mySlides" src="img/ativa2.jpg" style="width:100%">
  <img class="mySlides" src="img/myvi3.png" style="width:100%">
  <img class="mySlides" src="img/ativa1.jpg" style="width:100%">
  <img class="mySlides" src="img/myvi4.png" style="width:100%">
  <div class="w3-center w3-container w3-section w3-large w3-text-white w3-display-bottommiddle" style="width:100%">
    <div class="w3-left w3-hover-text-khaki" onclick="plusDivs(-1)">&#10094;</div>
    <div class="w3-right w3-hover-text-khaki" onclick="plusDivs(1)">&#10095;</div>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(1)"></span>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(2)"></span>
    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(3)"></span>
	<span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(4)"></span>
  </div></center></br></br></br></br>
</div>

<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" w3-white", "");
  }
  x[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " w3-white";
}
</script>
	
	<body>

<br><center><h2>About Us</h2></center></br>

<div class="container">
  <img src="img/about.jpeg" alt="" style="width:100%;">
  <div class="content">
    <h1>Perodua Car Store</h1>
    <p>Established in 1993, Perodua aims to be the leading affordable automotive brand regionally with global standards. We offer products and services geared towards your various needs and wants, supported by a far-reaching nationwide sales and service network for the ultimate convenience of our valued customers..</p>
  </div>
</div>

<body>

<br><center><h2>Follow us on</h2></br>


<a href="https://www.facebook.com/Perodua/" class="fa fa-facebook"></a>
<a href="https://www.instagram.com/perodua/" class="fa fa-instagram"></a>
<a href="https://www.youtube.com/c/Perodua" class="fa fa-youtube"></a></center>
      
</body>
      

</body>
</body>
</html>