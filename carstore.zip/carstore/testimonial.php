<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Testimonial</title>
	<link rel="stylesheet" href="css/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap-grid.css" rel="stylesheet"> 
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>
<style>
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #000000;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}

* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  font-size: 17px;
}

.container {
  position: relative;
  max-width: 800px;
  margin: 0 auto;
}

.container img {vertical-align: middle;}

.container .content {
  position: absolute;
  bottom: 0;
  background: rgb(0, 0, 0); /* Fallback color */
  background: rgba(0, 0, 0, 0.5); /* Black background with 0.5 opacity */
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
}
body{
	background:#fff;
	height:70vh;
	font-family:poppins;
}

.container{
	margin-top:15%;
	bottom: 0;
}

:root {
            --first_color: #15241c;
            --second-color: #09382f;
            --third-color: #FF882E;
            --fourth-color:#E55E2E;
            --fifth-color:#F8F1E0;
            --sixth-color : #EC9937;
        }

        .Testimonials {
            display: flex;
            flex-direction: column;
            justify-content: space-around;
            align-items: center;
            max-width: 100%;
            margin: 40px 0px;
        }

        .Testimonials_title h2 {
            font-size: 42px;
            letter-spacing: -2px;
            font-weight: 700;
            letter-spacing: 0;
            margin-bottom: 30px;
            text-align: center;
            color: var(--first_color);
        }

        .Testimonials_title>p {
            max-width: 900px;
            margin-left: auto;
            margin-right: auto;
            margin-top: 10px;
            margin-bottom: 40px;
            font-weight: 300;
            text-align: center;

        }


        .testimonials_container {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            position: relative;
        }


        .testimonials_container_center {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
        }

        .testimonials_content {
            position: relative;
            transition: all .3s ease-in-out;
            transform: scale(0.9);
            opacity: 0.9;
        }

        .testimonials_avatar {
            position: absolute;
            left: 50%;
            top: -30px;
            width: 90px;
            height: 90px;
            margin-left: -45px;
            z-index: 1;
        }

        .testimonials_avatar img {
            width: 90px;
            height: 90px;
            border-radius: 100%;
            border: 6px solid #fff;
            box-shadow: 0 9px 26px rgba(58, 87, 135, 0.1);
        }

        .testimonials_text {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 75px 50px 75px;
            overflow: hidden;
            background: var(--third-color);
            border: 1ps solid #f1f1f1;
            border-radius: 10px;
            transition: all .3s ease-in-out;
        }

        .testimonials_text_after {
            font-style: normal;
            font-weight: normal;
            text-decoration: inherit;
            position: absolute;
            color: var(--fifth-color);
            opacity: .3;
            font-size: 35px;
            transition: all 400ms linear;
            bottom: 25px;
            right: 30px;
        }
		 .testimonials_text_before {
            font-style: normal;
            font-weight: normal;
            text-decoration: inherit;
            position: absolute;
            color: var(--fifth-color);
            opacity: .3;
            font-size: 35px;
            transition: all 400ms linear;
            top: 25px;
            left: 30px;
        }


        .testimonials_text p {
            color: var(--second-color);
            font-size: 14px;
            font-family: Georgia, "Times New Roman", Times, serif;
            font-style: italic;
            line-height: 24px;
            padding-bottom: 10px;
            font-weight: 500;
        }

        .testimonials_information h3 {
            font-weight: 600;
            color: var(--second-color);
            ;
            font-size: 18px;
        }
		.testimonials_information h4 {
            font-weight: 400;
            font-size: 12px;
            padding-top: 6px;
            color: var(--second-color);
            ;
        }

        .testimonials_container_center .active {
            opacity: 1;
            transform: scale(1.0);
            width: 100%;
            flex-grow: 6;
        }

        .testimonials_container_center .active .testimonials_text {
            background: var(--fourth-color);
            box-shadow: 0 9px 26px rgba(58, 87, 135, 0.1);
        }

        .listing-carousel-button {
            position: relative;
            width: 80px;
            height: 50px;
            z-index: 1;
            cursor: pointer;
            background: var(--second-color);
            box-shadow: 0 9px 26px rgba(58, 87, 135, 0.45);
            transition: all 200ms linear;
            outline: none;
        }
		.listing-carousel-button.listing-carousel-button-next {
            padding-right: 20px;
            border-radius: 60px 0 0 60px;
        }

        .listing-carousel-button.listing-carousel-button-prev {
            padding-left: 20px;
            border-radius: 0 60px 60px 0;
        }

        .listing-carousel-button.listing-carousel-button-next:hover {
            right: -15px;
            background: rgba(6, 27, 65, 0.4);
        }

        .listing-carousel-button.listing-carousel-button-prev:hover {
            left: -15px;
            background: rgba(6, 27, 65, 0.4);
        }
		
.fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

</style>
<body>
		<div class="wrapper">
			<nav class="navbar">
				<img class="logo" src="img/car_icon.png" href="#">
				<ul>
					<li><a href="home.php">Home</a></li>
					<li>
						<div class="dropdown">
							<a href="model.html"<span>Model</span></a>
								<div class="dropdown-content">
									<a href="ativa_detail.html">Ativa detail</a>
									<a href="myvi_detail.html">Myvi detail</a>

								</div>
						
						</div>
					</li>
					<li><a href="promotion.html">Promotion</a></li>
					<li><a class="active">Testimonial</a></li>
					<li><a href="contactus.php">Contact Us</a></li>
				</ul>
			</nav>
			
	</div>

</body>
<body>
    <br><br><br><section id="Testimonials"></br></br></br>
        <div class="Testimonials_top">
            <div class="Testimonials_title">
                <h2>Testimonials</h2>
                <p>What our client say about us.</p>
            </div>
        </div>
        <div class="Testimonials_bottom">
            <div class="testimonials_container">
                <div class="testimonials_container_left">
                    <div class="listing-carousel-button listing-carousel-button-prev"><i class="fa fa-caret-left"
                            style="color: #fff"></i></div>
                </div>

                <div class="testimonials_container_center">
                    <div class="testimonials_content">
                        <div class="testimonials_avatar">
                            <img src="img/fatin.jpeg" alt="">
                        </div>

                        <div class="testimonials_text_before"><i class="fa fa-quote-right"></i></div>
				<div class="testimonials_text">
                            <p>Absolutely without a doubt the best around...I won't go anywhere else to buy a vehicle. This is my 4th and 5th purchase with Jon. There is no reason to go anywhere else!


                            </p>
                            <div class="testimonials_information">
                                <h3>FATIN NABIHAH</h3>
                                <h4>Software Engineer</h4>
                            </div>
                        </div>
                        <div class="testimonials_text_after"><i class="fa fa-quote-left"></i></div>
                    </div>

                    <div class="testimonials_content active">
                        <div class="testimonials_avatar">
                            <img src="img/syaf.jpeg" alt="">
                        </div>

                        <div class="testimonials_text_before"><i class="fa fa-quote-right"></i></div>

                        <div class="testimonials_text">
                            <p>I have been looking for two years for this car at every Perodua dealership from coast to coast. 
							My dealings with Perodua Car Store was very professional. They gave me every detailed about the car before 
							I made the trip to pick up and drive it back home. Great people to work with. You will be seeing more 
							business from my friends. Thank you, Perodua Car Store.


                            </p>
                            <div class="testimonials_information">
                                <h3>SYAFERA ZAINON</h3>
                                <h4>Content Analyst</h4>
                            </div>
                        </div>
                        <div class="testimonials_text_after"><i class="fa fa-quote-left"></i></div>
                    </div>

                    <div class="testimonials_content">
                        <div class="testimonials_avatar">
                            <img src="img/wahida.jpeg" alt="">
                        </div>

                        <div class="testimonials_text_before"><i class="fa fa-quote-right"></i></div>

                        <div class="testimonials_text">
                            <p>Thanks to all at Perodua Car Store for making my recent purchase a very pleasant experience. The entire process was thorough, honest and professional. I highly recommend Perodua Car Store.
				
.
                            </p>

                            <div class="testimonials_information">
                                <h3>WAHIDA</h3>
                                <h4>Programmer</h4>
                            </div>
                        </div>
                        <div class="testimonials_text_after"><i class="fa fa-quote-left"></i></div>
                    </div>
                </div>

                <div class="testimonials_container_right">
                    <div class="listing-carousel-button listing-carousel-button-next"><i class="fa fa-caret-right"
                            style="color: #fff"></i></div>
                </div>
            </div>
        </div>
    </section>
	
	<br><center><h2>Follow us on</h2></br>


<a href="https://www.facebook.com/Perodua/" class="fa fa-facebook"></a>
<a href="https://www.instagram.com/perodua/" class="fa fa-instagram"></a>
<a href="https://www.youtube.com/c/Perodua" class="fa fa-youtube"></a></center>
</body>
</body>

</html>				